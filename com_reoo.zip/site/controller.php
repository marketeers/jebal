<?php
/**
 * @version $Id$
 * @package    unitsearch
 * @subpackage _ECR_SUBPACKAGE_
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.easy-joomla.org}
 * @author     Created on 12-Jan-2011
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * unitsearch default Controller
 *
 * @package    unitsearch
 * @subpackage Controllers
 */
class reooController extends JControllerLegacy
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
	    $app    = JFactory::getApplication();
        $pathway = $app->getPathway();
        $pathway->addItem('My Units', 'component/reoo/?view=customerunits');
		parent::display();
	}// function
	
}// class
